rm linear_correlation.data mutual_information.data matlab_metadata.mat;
rm -r J*;
rm *.*~ *~;