#!/bin/bash                                                                                                                          

for (( c=1; c<=5; c++ ))
do
  qdel $c;
done



